<div id="desplegable">
		<nav id="menu">
			<ul>
				<li><a href="index.html">Inicio</a></li>
				<li><a href="quienes-somos/index.html">Quienes somos</a>
					<ul>
					  <li><a href="quienes-somos/index.html#og">Objetivos generales</a></li>
					  <li><a href="quienes-somos/index.html#oe">Objetivos específicos</a></li>
					  <li><a href="quienes-somos/index.html#mi">Misión</a></li>
					  <li><a href="quienes-somos/index.html#vi">Visión</a></li>
					</ul>
				</li>
				<li><a href="contacto/index.html">Contacto</a></li>
			</ul>
		</nav>
</div>