<div id="desplegable">
		<nav id="menu">
			<ul>
				<li><a href="index.html">Inicio</a></li>
				<li><a href="quienes-somos/index.html">Quienes somos</a>
					<ul>
					  <li><a href="quienes-somos/index.html#og">Objetivos generales</a></li>
					  <li><a href="quienes-somos/index.html#oe">Objetivos específicos</a></li>
					  <li><a href="quienes-somos/index.html#mi">Misión</a></li>
					  <li><a href="quienes-somos/index.html#vi">Visión</a></li>
					</ul>
				</li>
				<li><a href="#">Consultar datos</a>
					<ul>
					  <li><a href="consultar_producto.php">Colsultar producto</a>
					  	<ul>
					  		<li><a  href="consultar_precios.php">CONSULTAR PRECIO</a></li>
							<li><a  href="consultar_producto.php">CONSULTAR RANGO</a></li>
					  	</ul>
					  </li>
					</ul>
				</li>
				<li><a href="modifica_cliente.php">Modificar datos</a></li>
				<li><a href="contacto/index.html">Contacto</a></li>
			</ul>
		</nav>
</div>

<style type="text/css">
	.login{
		display: none;
	}
	.categorias{
		width: 20%;
	}
	.productos{
		width: 78%;
	}
</style>